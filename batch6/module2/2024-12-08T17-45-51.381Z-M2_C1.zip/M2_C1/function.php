<?php
// $n1 = 10;
// $n2 = 30;

// $sum = $n1 + $n2;
// echo $sum . "\n";

// $n3 = 70;
// $n4 = 50;
// $sum1 = $n3 + $n4;
// echo $sum1;


// Function Declaration
// function yourFunctionName(){

// }
function mySum($n1, $n2){
    $sum =  $n1 + $n2;
    echo $sum . "\n";
}


// Function Invokation/Call
mySum(5,9);
mySum(100,200);

// function mySub($n1, $n2){
//     $result =  $n1 - $n2;
//     // echo $result . "\n";
//     return $result;
// }
// echo mySub(100, 50);
