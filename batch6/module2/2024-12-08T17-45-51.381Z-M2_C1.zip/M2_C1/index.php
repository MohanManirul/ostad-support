<?php

// Operators
// Arithmatic (+, -, *, /, %, ** )
// $n1 = 2;
// $n2 = 3;


// echo $n1 + $n2;
// echo $n1 - $n2;
// echo $n1 * $n2;
// echo $n1 / $n2;
// echo $n1 % $n2;
// echo $n1 ** $n2;

// Logical Operators(&& - AND, || - OR, !-NOT) (True or False)

// $isActive = false;
// $isPending = true;

// || - OR operator 1 - T, 0 - F
// T | T = T
// T | F = T
// F | T = T
// F | F = F
// echo $isActive || $isPending;

// && - AND operator 1 - T, 0 - F
// T && T = T
// T && F = F
// F && T = F
// F && F = F
// $isActive = true;
// $isPending = true;
// echo $isActive && $isPending;

// ! - NOT operator 1 - T, 0 - F
// $isActive = false;
// $notIsActive = !$isActive;
// echo $notIsActive;

// Incrementor/Decrementor (Post, Pre)
// Post Incrementor($x++)
// $x + 1 => $x++
// $x = 5;
// echo "Before Increment :" . $x . "\n";
// $y = $x++;
// echo "Value of y : " . $y . "\n";
// echo "After Increment :" . $x . "\n";

// Pre Incrementor(++$x)
// $x = 5;
// echo "Before Increment :" . $x . "\n";
// $y = ++$x;
// echo "Value of y : " . $y . "\n";
// echo "After Increment :" . $x . "\n";


