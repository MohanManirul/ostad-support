<?php

// Write 1 to 500
// echo 1 . "\n";
// echo 2 . "\n";
// echo 3 . "\n";
// echo 4 . "\n";
// echo 5 . "\n";

// Loops (For, While, Do-While, Foreach)

// For Loop
// Write 1 to 5
// for($i=1; $i<=5; $i++){
//     echo $i . "\n";
// }

// While Loop
// $i=5;
// while($i<=5){
//     echo $i . "\n";
//     $i++;
// }

// Do-While Loop
// $i=1;
// do{
//     echo $i . "\n";
//     $i++;
// }while($i<=5);

// Foreach Loop

// $colors = ["Red", "Green", "Blue", "Yellow", "Pink", "Black", "White", "Orange", "Purple"];
// echo $colors[2];
// echo $colors[0];
// echo $colors[];
// echo count($colors);
// $lastIndex = arrayLength - 1;
// for($i=0; $i < count($colors); $i++){
//     echo $colors[$i] . "\n";
// }

// foreach ($varibales as $variable){

// }
// $colors = ["Red", "Green", "Blue", "Yellow", "Pink", "Black", "White", "Orange", "Purple"];
// foreach ($colors as $color){
//     echo $color."\n";
// }
// foreach ($colors as $index => $color){
//     echo $index+1 . " - ".$color."\n";
// }

// Break & Continue

// Break 

// for($i=1; $i<=5; $i++){
//     if($i==3){
//         break;
//     }
//     echo $i . "\n";     
// }

// Continue
// for($i=1; $i<=5; $i++){
//     if($i==3){
//        continue;
//     }
//     echo $i . "\n";     
// }
// $numbers = [1,2,3,4,5,6,7,8,9,10];
// for($i=0; $i < count($numbers); $i++){
//     if($numbers[$i] % 2 != 0){
//         continue;
//     }
//     echo $numbers[$i] . "\n";
// }

