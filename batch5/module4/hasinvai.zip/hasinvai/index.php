<?php 
$item = "Notebook";
$price = 100;
$quantity = 5;
$totalPrice = $price * $quantity;

// echo "The price of a $item is $price";
// print("The price of a $item is $price");
// printf("The price of a %s is %d", $item, $price);
printf("The price of a %s is %.2f", $item, $price);


