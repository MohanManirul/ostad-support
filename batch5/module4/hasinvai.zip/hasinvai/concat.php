<?php 
$firstName = "John";
$lastName = "Doe";

// echo $firstName ." ". $lastName; //concat
echo "$firstName $lastName";