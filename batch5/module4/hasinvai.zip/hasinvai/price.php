<?php 
$item = "Notebook";
$price = 100;
$quantity = 5;
$totalPrice = $price * $quantity;

echo "The price of a $item is $price";
echo "\n";
echo "The total price of $quantity {$item}s is $totalPrice";