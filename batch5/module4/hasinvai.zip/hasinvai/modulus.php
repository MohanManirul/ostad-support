<?php 
//modulus 
//remainder of a division

$number = 19;
$divisor = 4;

$remainder = $number % $divisor;
// echo $remainder;

echo "The remainder of $number divided by $divisor is $remainder";
