<?php 
$numberOne = 10;
$numberTwo = 20;
$name = "John Doe";

// const PI = 3.14;
// const PI = 3.142; // This will throw an error

// define("PI", 3.14);
// define("PI", 3.142); // This will not throw an error

// echo PI;

$numberOne= 30;

/*
echo $numberOne;
echo "\n";
echo $numberTwo;
echo "\n";
echo $numberOne + $numberTwo;
echo "\n";
echo $numberTwo - $numberOne;
echo "\n";  
echo $numberOne * $numberTwo;
echo "\n";
echo $numberTwo / $numberOne;
*/

echo $name;
